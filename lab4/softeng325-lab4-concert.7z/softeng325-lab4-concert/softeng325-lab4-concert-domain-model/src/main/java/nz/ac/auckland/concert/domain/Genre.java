package nz.ac.auckland.concert.domain;

public enum Genre {
	Pop, HipHop, RhythmAndBlues, Acappella, Metal, Rock 
}

