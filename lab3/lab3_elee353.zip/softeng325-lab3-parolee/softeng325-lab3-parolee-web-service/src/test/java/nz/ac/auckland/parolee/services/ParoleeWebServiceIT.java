package nz.ac.auckland.parolee.services;


import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.List;
import java.util.Set;

import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Link;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;

import nz.ac.auckland.parolee.domain.Address;
import nz.ac.auckland.parolee.domain.CriminalProfile;
import nz.ac.auckland.parolee.domain.CriminalProfile.Offence;
import nz.ac.auckland.parolee.domain.Curfew;
import nz.ac.auckland.parolee.domain.Gender;
import nz.ac.auckland.parolee.domain.GeoPosition;
import nz.ac.auckland.parolee.domain.Movement;
import nz.ac.auckland.parolee.dto.Parolee;

import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.joda.time.LocalTime;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParoleeWebServiceIT {
	private static final String WEB_SERVICE_URI = "http://localhost:10000/services/parolees";
	
	private static final Logger _logger = LoggerFactory.getLogger(ParoleeWebServiceIT.class);

	private static Client _client;

	/**
	 * One-time setup method that creates a Web service client.
	 */
	@BeforeClass
	public static void setUpClient() {
		_client = ClientBuilder.newClient();
	}

	/**
	 * Runs before each unit test to restore Web service database. This ensures
	 * that each test is independent; each test runs on a Web service that has
	 * been initialised with a common set of Parolees.
	 */
	@Before
	public void reloadServerData() {
		Response response = _client
				.target(WEB_SERVICE_URI).request()
				.put(null);
		response.close();

		// Pause briefly before running any tests. Test addParoleeMovement(),
		// for example, involves creating a timestamped value (a movement) and
		// having the Web service compare it with data just generated with 
		// timestamps. Joda's Datetime class has only millisecond precision, 
		// so pause so that test-generated timestamps are actually later than 
		// timestamped values held by the Web service.
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
		}
	}

	/**
	 * One-time finalisation method that destroys the Web service client.
	 */
	@AfterClass
	public static void destroyClient() {
		_client.close();
	}

	/**
	 * Tests that the Web service can create a new Parolee.
	 */
	@Test
	public void addParolee() {
		Address homeAddress = new Address("34", "Appleby Road", "Remuera",
				"Auckland", "1070");
		Parolee zoran = new Parolee("Salcic", "Zoran", Gender.MALE,
				new LocalDate(1958, 5, 17), homeAddress, null);

		Response response = _client
				.target(WEB_SERVICE_URI).request()
				.post(Entity.xml(zoran));
		if (response.getStatus() != 201) {
			fail("Failed to create new Parolee");
		}

		String location = response.getLocation().toString();
		response.close();

		// Query the Web service for the new Parolee.
		Parolee zoranFromService = _client.target(location).request()
				.accept(MediaType.APPLICATION_XML).get(Parolee.class);

		// The original local Parolee object (zoran) should have a value equal
		// to that of the Parolee object representing Zoran that is later
		// queried from the Web service. The only exception is the value
		// returned by getId(), because the Web service assigns this when it
		// creates a Parolee.
		assertEquals(zoran.getLastname(), zoranFromService.getLastname());
		assertEquals(zoran.getFirstname(), zoranFromService.getFirstname());
		assertEquals(zoran.getGender(), zoranFromService.getGender());
		assertEquals(zoran.getDateOfBirth(), zoranFromService.getDateOfBirth());
		assertEquals(zoran.getHomeAddress(), zoranFromService.getHomeAddress());
		assertEquals(zoran.getCurfew(), zoranFromService.getCurfew());
		assertEquals(zoran.getLastKnownPosition(),
				zoranFromService.getLastKnownPosition());
	}

	/**
	 * Tests that the Web serves can process requests to record new Parolee
	 * movements.
	 */
	@Test
	public void addParoleeMovement() {
		LocalDateTime now = new LocalDateTime();
		Movement newLocation = new Movement(now, new GeoPosition(
				-36.848238, 174.762212));

		Response response = _client
				.target(WEB_SERVICE_URI + "/1/movements")
				.request().post(Entity.xml(newLocation));
		if (response.getStatus() != 204) {
			fail("Failed to create new Movement");
		}
		response.close();

		// Query the Web service for the Parolee whose location has been
		// updated.
		Parolee oliver = _client
				.target(WEB_SERVICE_URI + "/1").request()
				.accept(MediaType.APPLICATION_XML).get(Parolee.class);

		// Check that the Parolee's location was updated.
		assertEquals(newLocation, oliver.getLastKnownPosition());
	}

	/**
	 * Tests that the Web service can process Parolee update requests.
	 */
	@Test
	public void updateParolee() {
		final String targetUri = WEB_SERVICE_URI + "/2";

		// Query a Parolee (Catherine) from the Web service.
		Parolee catherine = _client.target(targetUri).request()
				.accept(MediaType.APPLICATION_XML).get(Parolee.class);

		Address originalAddress = catherine.getHomeAddress();
		assertNull(catherine.getCurfew());

		// Update some of Catherine's details.
		Address newAddress = new Address("40", "Clifton Road", "Herne Bay",
				"Auckland", "1022");
		catherine.setHomeAddress(newAddress);
		Curfew newCurfew = new Curfew(newAddress, new LocalTime(21, 00),
				new LocalTime(7, 00));
		catherine.setCurfew(newCurfew);

		Response response = _client.target(targetUri).request()
				.put(Entity.xml(catherine));
		if (response.getStatus() != 204)
			fail("Failed to update Parolee");
		response.close();

		// Requery Parolee from the Web service.
		Parolee updatedCatherine = _client.target(targetUri).request()
				.accept(MediaType.APPLICATION_XML).get(Parolee.class);

		// Parolee's home address should have changed.
		assertFalse(originalAddress.equals(updatedCatherine.getHomeAddress()));
		assertEquals(newAddress, updatedCatherine.getHomeAddress());

		// Curfew should now be set.
		assertEquals(newCurfew, updatedCatherine.getCurfew());
	}

	/**
	 * Tests that the Web service can add dissassociates to a Parolee.
	 */
	@Test
	public void updateDissassociates() {
		// Query Parolee Catherine from the Web service.
		Parolee catherine = _client
				.target(WEB_SERVICE_URI + "/2").request()
				.accept(MediaType.APPLICATION_XML).get(Parolee.class);

		// Query a second Parolee, Nasser.
		Parolee nasser = _client
				.target(WEB_SERVICE_URI + "/3").request()
				.accept(MediaType.APPLICATION_XML).get(Parolee.class);

		// Query Catherines's dissassociates.
		Set<Parolee> dissassociates = _client
				.target(WEB_SERVICE_URI + "/1/dissassociates")
				.request().accept(MediaType.APPLICATION_XML)
				.get(new GenericType<Set<Parolee>>() {
				});

		// Catherine should not yet have any recorded dissassociates.
		assertTrue(dissassociates.isEmpty());

		// Request that Nasser is added as a dissassociate to Catherine. 
		// Because an object of a parameterized type is being sent to the Web
		// service, it must be wrapped in a GenericEntity, so that the generic
		// type information necessary for marshalling is preserved.
		dissassociates.add(nasser);
		GenericEntity<Set<Parolee>> entity = new GenericEntity<Set<Parolee>>(
				dissassociates) {
		};
		
		Response response = _client
				.target(WEB_SERVICE_URI + "/1/dissassociates")
				.request().put(Entity.xml(entity));
		if (response.getStatus() != 204)
			fail("Failed to update Parolee");
		response.close();

		// Requery Catherine's dissassociates. The GET request is expected to
		// return a List<Parolee> object; since this is a parameterized type, a
		// GenericType wrapper is required so that the data can be 
		// unmarshalled.
		Set<Parolee> updatedDissassociates = _client
				.target(WEB_SERVICE_URI + "/1/dissassociates")
				.request().accept(MediaType.APPLICATION_XML)
				.get(new GenericType<Set<Parolee>>() {
				});
		// The Set of Parolees returned in response to the request for
		// Catherine's dissassociates should contain one object with the same
		// state (value) as the Parolee instance representing Nasser.
		assertTrue(updatedDissassociates.contains(nasser));
		assertEquals(1, updatedDissassociates.size());
	}

	@Test
	public void updateCriminalProfile() {
		final String targetUri = WEB_SERVICE_URI + "/1/criminal-profile";

		CriminalProfile profileForOliver = _client.target(targetUri).request()
				.accept(MediaType.APPLICATION_XML).get(CriminalProfile.class);

		// Amend the criminal profile.
		profileForOliver.addConviction(new CriminalProfile.Conviction(
				new LocalDate(), "Shoplifting", Offence.THEFT));

		// Send a Web service request to update the profile.
		Response response = _client.target(targetUri).request()
				.put(Entity.xml(profileForOliver));
		if (response.getStatus() != 204)
			fail("Failed to update CriminalProfile");
		response.close();

		// Requery Oliver's criminal profile.
		CriminalProfile reQueriedProfile = _client.target(targetUri).request()
				.accept(MediaType.APPLICATION_XML).get(CriminalProfile.class);

		// The locally updated copy of Oliver's CriminalProfile should have
		// the same value as the updated profile obtained from the Web service.
		assertEquals(profileForOliver, reQueriedProfile);
	}

	/**
	 * Tests that the Web service can handle requests to query a particular
	 * Parolee.
	 */
	@Test
	public void queryParolee() {
		Parolee parolee = _client
				.target(WEB_SERVICE_URI + "/1").request()
				.accept(MediaType.APPLICATION_XML).get(Parolee.class);

		assertEquals(1, parolee.getId());
		assertEquals("Sinnen", parolee.getLastname());
	}
	
	/**
	 * Similar to queryParolee(), but this method retrieves the Parolee using
	 * via a Response object. Because a Response object is used, headers and
	 * other HTTP response message data can be examined.
	 */
	@Test
	public void queryParoleeWithResponse() {
		Response response = _client
				.target(WEB_SERVICE_URI + "/1").request( ).get( );
		Parolee parolee = response.readEntity(Parolee.class);
		
		// Get the headers and print them out.
		MultivaluedMap<String,Object> headers = response.getHeaders( );
		_logger.info("Dumping HTTP response message headers ...");
		for(String key : headers.keySet()) {
			_logger.info(key + ": " + headers.getFirst(key));
		}
		response.close( );
	}

	/**
	 * Tests that the Web service processes requests for all Parolees.
	 */
	@Test
	public void queryAllParolees() {
		List<Parolee> parolees = _client
				.target(WEB_SERVICE_URI + "?start=1&size=3").request()
				.accept(MediaType.APPLICATION_XML)
				.get(new GenericType<List<Parolee>>() {
				});
		assertEquals(3, parolees.size());
	}
	
	/**
	 * Tests that the Web service processes requests for Parolees using header
	 * links for HATEOAS.
	 */
	@Test
	public void queryAllParoleesUsingHATEOAS() {
		// Make a request for Parolees (note that the Web service has default 
		// values of 1 for the query parameters start and size. 
		Response response = _client
				.target(WEB_SERVICE_URI).request().get();
		
		// Extract links and entity data from the response.
		Link previous = response.getLink("prev");
		Link next = response.getLink("next");
		List<Parolee> parolees = response.readEntity(new GenericType<List<Parolee>>() {});
		response.close();
		
		// The Web service should respond with a list containing only the 
		// first Parolee.
		assertEquals(1, parolees.size());
		assertEquals(1, parolees.get(0).getId());
		
		// Having requested the only the first parolee (by default), the Web 
		// service should respond with a Next link, but not a previous Link.
		assertNull(previous);
		assertNotNull(next);
		
		// Invoke next link and extract response data.
		response = _client
				.target(next).request().get();
		previous = response.getLink("prev");
		next = response.getLink("next");
		parolees = response.readEntity(new GenericType<List<Parolee>>() {});
		response.close();
		
		// The second Parolee should be returned along with Previous and Next 
		// links to the adjacent Parolees.
		assertEquals(1, parolees.size());
		assertEquals(2, parolees.get(0).getId());
		assertEquals("<" + WEB_SERVICE_URI + "?start=1&size=1>; rel=\"prev\"", previous.toString());
		assertNotNull("<" + WEB_SERVICE_URI + "?start=1&size=1>; rel=\"prev\"", next.toString());
	}

	/**
	 * Tests that the Web service can process requests for a particular
	 * Parolee's movements.
	 */
	@Test
	public void queryParoleeMovements() {
		List<Movement> movementsForOliver = _client
				.target(WEB_SERVICE_URI + "/1/movements")
				.request().accept(MediaType.APPLICATION_XML)
				.get(new GenericType<List<Movement>>() {
				});

		// Oliver has 3 recorded movements.
		assertEquals(3, movementsForOliver.size());
	}
}
